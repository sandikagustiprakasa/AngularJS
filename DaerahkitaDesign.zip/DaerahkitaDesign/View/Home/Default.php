    <div class="container">
        <div>
            <!--<img src="picture/jb.jpg" width="100%" height="100%" />-->
        </div>

        <div class="row">
            <div class="col-lg-12">
              <h3 id="type-blockquotes">Aktivitas Baru</h3>
              <hr>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-6">
              <div class="bs-component">
                <blockquote>
                  <p>Mie ayam terenak di Kec.Curug Kab. Tangerang ternyata ada!</p>
                  <small>Robby Haryanto <cite title="Source Title">11 Maret 2016 14:48</cite></small>
                  <small><b>Kuliner</b>, Curug, Kab Tangerang</small>
                </blockquote>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="bs-component">
                <blockquote class="blockquote-reverse">
                  <p>Tempatnya nggak terlalu bagus tapi enak buat santai atau nongkrong. Situ Cipondoh Kota Tangerang.</p>
                  <small>Dama Rizqiya <cite title="Source Title">11 Maret 2016 14:40</cite></small>
                  <small><b>Tongkrongan</b>, Cipondoh, Kota Tangerang Selatan</small>
                </blockquote>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="bs-component">
                <blockquote>
                  <p>Wahana kaya di dufan, Kab Tangerang Citra Raya</p>
                  <small>Rio Adhi Pratama <cite title="Source Title">11 Maret 2016 14:29</cite></small>
                  <small><b>Liburan</b>, Cikupa, Kab Tangerang</small>
                </blockquote>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="bs-component">
                <blockquote class="blockquote-reverse">
                  <p>Perum Karawaci Surganya makanan broooo!</p>
                  <small>Sandika Gusti Prakasa <cite title="Source Title">11 Maret 2016 14:20</cite></small>
                  <small><b>Kuliner</b>, Karawaci, Kota Tangerang</small>
                </blockquote>
              </div>
            </div>
          </div>
                            
    </div>