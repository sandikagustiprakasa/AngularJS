<div class="container" ng-controller="HomeAboutController as vcAbout" >
    <p>test</p>
    <button type="button" class="btn btn-primary" ng-click="vcAbout.kilk()">button</button>
</div>