(function () {
    'use strict';

    var DaerahKita = angular
        .module('DaerahKita')
        .controller('MenuDefaultMenuController', MenuDefaultMenuController);

    MenuDefaultMenuController.$inject = ['$scope', '$window', '$location', '$http', '$timeout', 'DaerahKitaFactory'];

    function MenuDefaultMenuController($scope, $window, $location, $http, $timeout, DaerahKitaFactory) {

        // Declaration
        var vc = this;
        var vf = DaerahKitaFactory;

        //==========================================================

        vc.PageLoad = function () {

        }
        
        vc.MainMenuClick = function (URL) {
            $location.path(URL);
        }

        // Function For Select Record List
        //==========================================================

        vc.PageLoad();

        return;
    }
})();
