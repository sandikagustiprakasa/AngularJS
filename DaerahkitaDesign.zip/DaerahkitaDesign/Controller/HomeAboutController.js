(function () {
    'use strict';

    var DaerahKita = angular
        .module('DaerahKita')
        .controller('HomeAboutController', HomeAboutController);

    HomeAboutController.$inject = ['$scope', '$window', '$location', '$http', '$timeout', 'DaerahKitaFactory'];

    function HomeAboutController($scope, $window, $location, $http, $timeout, DaerahKitaFactory) {

        // Declaration
        var vc = this;
        var vf = DaerahKitaFactory;

        //==========================================================

        vc.PageLoad = function () {

        }
        
        vc.kilk = function () {
           alert('Hallo');
        }
        
        //vc.ListCaseStatusClick = function (ItemCaseStatus) {
        //    vf.ItemCaseStatus = ItemCaseStatus;
        //    $location.path("content/casestatus_form");
        //}


        // Function For Select Record List
        //==========================================================

        vc.PageLoad();

        return;
    }
})();
