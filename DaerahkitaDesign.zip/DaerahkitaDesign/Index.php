<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" ng-app="DaerahKita">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>DaerahKita.co.id</title>
<link href="dist/css/bootstrap.min.css" rel='stylesheet' />
<link href="dist/css/site.css" rel='stylesheet' />
<script src="dist/js/jquery.min.js"></script>
<script src="dist/js/bootstrap.min.js"></script>
<base href="<?php echo "http://" . $_SERVER['SERVER_NAME'].":81".$_SERVER['REQUEST_URI']; ?>">
</head>

<body>
    
    <div ng-include="'View/Menu/DefaultMenu.php'"></div>

    <div ng-view=""></div>

    <script src="dist/js/angular.js"></script>
    <script src="dist/js/angular-route.js"></script>
    <script src="dist/js/angular-ui-router.js"></script>
    <script src="dist/js/angular-cookies.js"></script>
    <script src="dist/js/angular-animate.js"></script>
    <script src="dist/js/angular-sanitize.js"></script>
    <script src="dist/js/angular-touch.js"></script>
    
    <script src="dist/ng-listsoftmedia/DaerahKita.js"></script>
    <script src="dist/ng-listsoftmedia/DaerahKitaFactory.js"></script>
    
    <script src="Controller/MenuDefaultMenuController.js"></script>
    <script src="Controller/HomeAboutController.js"></script>
    
</body>
</html>